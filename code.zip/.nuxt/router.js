import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _43e496a6 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _5dba3322 = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _60bb1cc0 = () => interopDefault(import('../pages/login/login' /* webpackChunkName: "" */))
const _07116d0c = () => interopDefault(import('../pages/login/register' /* webpackChunkName: "" */))
const _5899fef4 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _33ed20e6 = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _5b824a20 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _8b05785a = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _43e496a6,
    children: [{
      path: "",
      component: _5dba3322,
      name: "home"
    }, {
      path: "/login",
      component: _60bb1cc0,
      name: "login"
    }, {
      path: "/register",
      component: _07116d0c,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _5899fef4,
      name: "profile"
    }, {
      path: "/settings",
      component: _33ed20e6,
      name: "settings"
    }, {
      path: "/editor",
      component: _5b824a20,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _8b05785a,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
